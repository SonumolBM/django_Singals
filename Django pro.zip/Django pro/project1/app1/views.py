from django.contrib.auth.models import User

# Create a new user to trigger the post_save signal
user = User.objects.create(username="testuser", password="testpassword")
print("User save finished.")
