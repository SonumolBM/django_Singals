# myapp/signals.py
import time
from django.db.models.signals import post_save
from django.contrib.auth.models import User
from django.dispatch import receiver

@receiver(post_save, sender=User)
def user_saved_handler(sender, instance, **kwargs):
    print("Signal received for user save.")
    time.sleep(5)  # Simulate a delay to show synchronous behavior
    print("Signal handler executed.")
